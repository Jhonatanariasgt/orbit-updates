﻿<#
  ORBIT Updater
  Busca atualizacoes no GitHub (repositorio publico orbit-updates, pasta updates/) e instala sozinho:
    - system : o app ORBIT.exe, o plugin VST3, este atualizador e o manual
    - tones  : timbres oficiais (presets .orbit) em Documentos\ORBIT\Presets\ORBIT Timbres
    - images : imagens dos equipamentos em Documentos\ORBIT\Images

  Modos:
    -Launch       abre o ORBIT: confere o sistema antes (rapido, sem internet segue em frente), abre o app e
                  depois baixa timbres e imagens em segundo plano
    -Silent       ao entrar no Windows: atualiza o que der sem perguntar nada (o sistema so se o ORBIT estiver fechado)
    -Interactive  "Verificar atualizacoes": mostra uma janela com o resultado
    -InstallFrom  pasta com manifest.json e pacotes locais (usado pelo instalador)
    -TestRoot     pasta que substitui LOCALAPPDATA, Documentos e atalhos (testes)
#>
param(
    [switch] $Launch,
    [switch] $Silent,
    [switch] $Interactive,
    [string] $InstallFrom = "",
    [string] $TestRoot = "",
    [string] $ManifestUrl = ""
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"   # a barra de progresso do PowerShell 5 deixa o download muito lento
try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12 } catch {}
Add-Type -AssemblyName System.IO.Compression.FileSystem

#==============================================================================
# Caminhos
function Get-OrbitPaths([string] $root)
{
    if ($root) {
        $local = Join-Path $root "LocalAppData"; $docs = Join-Path $root "Documents"
    } else {
        $local = $env:LOCALAPPDATA; $docs = [Environment]::GetFolderPath("MyDocuments")
    }
    $app = Join-Path $local "Programs\ORBIT"
    [pscustomobject]@{
        App      = $app
        Exe      = Join-Path $app "ORBIT.exe"
        Updater  = Join-Path $app "Updater"
        Versions = Join-Path $app "versions.json"
        Vst3     = Join-Path $local "Programs\Common\VST3\ORBIT.vst3"
        Docs     = Join-Path $docs "ORBIT"
        Tones    = Join-Path $docs "ORBIT\Presets\ORBIT Timbres"
        Images   = Join-Path $docs "ORBIT\Images"
        Log      = Join-Path $app "Updater\updater.log"
        Temp     = Join-Path ([IO.Path]::GetTempPath()) ("orbit-update-" + [Guid]::NewGuid().ToString("N").Substring(0, 8))
    }
}
$P = Get-OrbitPaths $TestRoot

function Write-Log([string] $msg)
{
    $line = "{0:yyyy-MM-dd HH:mm:ss}  {1}" -f (Get-Date), $msg
    try {
        New-Item -ItemType Directory -Force -Path (Split-Path $P.Log) | Out-Null
        if ((Test-Path $P.Log) -and (Get-Item $P.Log).Length -gt 1MB) { Move-Item -Force $P.Log ($P.Log + ".old") }
        Add-Content -Path $P.Log -Value $line -Encoding UTF8
    } catch {}
    $script:report += $msg
}
$script:report = @()

#==============================================================================
# Estado instalado
function Get-Installed
{
    $v = @{ system = "0.0.0"; tones = "0.0.0"; images = "0.0.0"; skip = @() }
    if (Test-Path $P.Versions) {
        try {
            $j = Get-Content $P.Versions -Raw -Encoding UTF8 | ConvertFrom-Json
            foreach ($k in @("system", "tones", "images")) { if ($j.$k) { $v[$k] = [string] $j.$k } }
            if ($j.skip) { $v.skip = @($j.skip) }          # pacotes que a pessoa escolheu nao receber (ex.: imagens)
        } catch {}
    }
    $v
}
function Save-Installed($v)
{
    New-Item -ItemType Directory -Force -Path $P.App | Out-Null
    ($v | ConvertTo-Json) | Set-Content -Path $P.Versions -Encoding UTF8
}
function Test-Newer([string] $available, [string] $installed)
{
    try { return ([version] $available) -gt ([version] $installed) } catch { return $available -ne $installed }
}

function Get-Config
{
    $cfg = Join-Path $PSScriptRoot "updater-config.json"
    $url = "https://raw.githubusercontent.com/Jhonatanariasgt/orbit-updates/main/updates/manifest.json"
    if (Test-Path $cfg) { try { $c = Get-Content $cfg -Raw | ConvertFrom-Json; if ($c.manifestUrl) { $url = $c.manifestUrl } } catch {} }
    if ($ManifestUrl) { $url = $ManifestUrl }
    $url
}

#==============================================================================
# Manifest e downloads (local ou GitHub)
function Get-Manifest([int] $timeout)
{
    if ($InstallFrom) {
        $m = Get-Content (Join-Path $InstallFrom "manifest.json") -Raw -Encoding UTF8 | ConvertFrom-Json
        return @{ Manifest = $m; Base = $InstallFrom; Local = $true }
    }
    $url = Get-Config
    $bust = $url + "?t=" + [DateTime]::UtcNow.Ticks          # o raw do GitHub guarda em cache por alguns minutos
    $r = Invoke-WebRequest -Uri $bust -TimeoutSec $timeout -UseBasicParsing -Headers @{ "Cache-Control" = "no-cache" }
    # le os bytes como UTF-8 e tira o BOM (o PowerShell 5 grava JSON com BOM e o ConvertFrom-Json nao aceita)
    $text = [Text.Encoding]::UTF8.GetString($r.RawContentStream.ToArray()).TrimStart([char] 0xFEFF)
    $m = $text | ConvertFrom-Json
    @{ Manifest = $m; Base = $url.Substring(0, $url.LastIndexOf("/")); Local = $false }
}

function Get-PackageFiles($src, $pkg)
{
    # baixa (ou pega do instalador) cada parte do pacote e confere o SHA-256
    New-Item -ItemType Directory -Force -Path $P.Temp | Out-Null
    $out = @()
    foreach ($f in $pkg.files) {
        $dest = Join-Path $P.Temp (Split-Path $f.path -Leaf)
        if ($src.Local) {
            $from = Join-Path $src.Base (Split-Path $f.path -Leaf)
            if (-not (Test-Path $from)) { $from = Join-Path $src.Base $f.path }
            Copy-Item -Force $from $dest
        } else {
            $url = $src.Base + "/" + (($f.path -split "/" | ForEach-Object { [Uri]::EscapeDataString($_) }) -join "/")
            Invoke-WebRequest -Uri $url -OutFile $dest -UseBasicParsing -TimeoutSec 600
        }
        $hash = (Get-FileHash -Algorithm SHA256 $dest).Hash.ToLowerInvariant()
        if ($hash -ne ([string] $f.sha256).ToLowerInvariant()) { throw "arquivo corrompido: $($f.path) (SHA-256 nao confere)" }
        $out += $dest
    }
    $out
}

function Expand-To([string] $zip, [string] $dest)
{
    # extrai sobrescrevendo (ZipFile.ExtractToDirectory do .NET Framework nao sobrescreve)
    $archive = [IO.Compression.ZipFile]::OpenRead($zip)
    try {
        foreach ($e in $archive.Entries) {
            $rel = $e.FullName -replace "/", "\"
            $target = [IO.Path]::GetFullPath((Join-Path $dest $rel))
            if (-not $target.StartsWith([IO.Path]::GetFullPath($dest), [StringComparison]::OrdinalIgnoreCase)) { continue }
            if ($rel.EndsWith("\")) { New-Item -ItemType Directory -Force -Path $target | Out-Null; continue }
            New-Item -ItemType Directory -Force -Path (Split-Path $target) | Out-Null
            [IO.Compression.ZipFileExtensions]::ExtractToFile($e, $target, $true)
        }
    } finally { $archive.Dispose() }
}

#==============================================================================
# Aplicar cada pacote
function Test-OrbitRunning
{
    $exe = [IO.Path]::GetFullPath($P.Exe)
    foreach ($p in @(Get-Process -Name "ORBIT" -ErrorAction SilentlyContinue)) {
        try { if ($p.Path -and ([IO.Path]::GetFullPath($p.Path) -ieq $exe)) { return $true } } catch { return $true }
    }
    $false
}

function Install-System([string[]] $zips, [string] $version)
{
    $stage = Join-Path $P.Temp "system"
    foreach ($z in $zips) { Expand-To $z $stage }
    New-Item -ItemType Directory -Force -Path $P.App | Out-Null
    # app, atualizador e manual
    foreach ($item in Get-ChildItem $stage) {
        if ($item.Name -eq "VST3") { continue }
        Copy-Item -Recurse -Force $item.FullName $P.App
    }
    # plugin VST3 (pasta VST3 do usuario; se uma DAW estiver com ele aberto, a copia falha e tenta de novo depois)
    $vstSrc = Join-Path $stage "VST3\ORBIT.vst3"
    if (Test-Path $vstSrc) {
        New-Item -ItemType Directory -Force -Path (Split-Path $P.Vst3) | Out-Null
        if (Test-Path $P.Vst3) { Remove-Item -Recurse -Force $P.Vst3 }
        Copy-Item -Recurse -Force $vstSrc $P.Vst3
    }
    # versao exibida em "Aplicativos instalados"
    if (-not $TestRoot) {
        $key = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\ORBIT"
        if (Test-Path $key) { Set-ItemProperty -Path $key -Name DisplayVersion -Value $version }
    }
}

function Install-Tones([string[]] $zips)
{
    # a pasta "ORBIT Timbres" e so dos timbres oficiais: e trocada inteira (os seus presets ficam fora dela)
    if (Test-Path $P.Tones) { Remove-Item -Recurse -Force $P.Tones }
    New-Item -ItemType Directory -Force -Path $P.Tones | Out-Null
    foreach ($z in $zips) { Expand-To $z $P.Tones }
}

function Install-Images([string[]] $zips)
{
    New-Item -ItemType Directory -Force -Path $P.Images | Out-Null
    foreach ($z in $zips) { Expand-To $z $P.Images }      # sobrescreve as oficiais, mantem as suas fotos
}

$names = @{ system = "Sistema"; tones = "Timbres"; images = "Imagens" }

# atualiza um pacote; devolve $true se instalou
function Update-Package($src, [string] $key, $installed, [switch] $Force)
{
    $pkg = $src.Manifest.packages.$key
    if (-not $pkg) { return $false }
    if ($installed.skip -contains $key) { return $false }
    if (-not $Force -and -not (Test-Newer $pkg.version $installed[$key])) { return $false }
    if ($key -eq "system" -and (Test-OrbitRunning)) {
        if ($Interactive) {
            Add-Type -AssemblyName System.Windows.Forms
            while (Test-OrbitRunning) {
                $r = [Windows.Forms.MessageBox]::Show("Existe uma versao nova do ORBIT ($($pkg.version)).`n`nFeche o ORBIT e clique em Repetir para atualizar.",
                                                       "ORBIT - Atualizacao", "RetryCancel", "Information")
                if ($r -ne "Retry") { Write-Log "Sistema $($pkg.version): adiado (ORBIT aberto)"; return $false }
            }
        } else { Write-Log "Sistema $($pkg.version) disponivel: sera instalado quando o ORBIT estiver fechado"; return $false }
    }
    Write-Log "$($names[$key]): instalando $($pkg.version) (era $($installed[$key]))"
    $zips = Get-PackageFiles $src $pkg
    switch ($key) {
        "system" { Install-System $zips $pkg.version }
        "tones"  { Install-Tones $zips }
        "images" { Install-Images $zips }
    }
    $installed[$key] = [string] $pkg.version
    Save-Installed $installed
    Write-Log "$($names[$key]): $($pkg.version) instalado"
    $true
}

function Show-Balloon([string] $text)
{
    try {
        Add-Type -AssemblyName System.Windows.Forms, System.Drawing
        $n = New-Object Windows.Forms.NotifyIcon
        $n.Icon = if (Test-Path $P.Exe) { [Drawing.Icon]::ExtractAssociatedIcon($P.Exe) } else { [Drawing.SystemIcons]::Information }
        $n.Visible = $true
        $n.ShowBalloonTip(6000, "ORBIT", $text, "Info")
        Start-Sleep -Seconds 7
        $n.Dispose()
    } catch {}
}

# janelinha "Atualizando..." enquanto o sistema e trocado antes de abrir o app
function Show-Busy([string] $text)
{
    try {
        Add-Type -AssemblyName System.Windows.Forms, System.Drawing
        $f = New-Object Windows.Forms.Form
        $f.Text = "ORBIT"; $f.Width = 380; $f.Height = 120; $f.StartPosition = "CenterScreen"; $f.FormBorderStyle = "FixedDialog"
        $f.ControlBox = $false; $f.TopMost = $true; $f.BackColor = [Drawing.Color]::FromArgb(18, 20, 26); $f.ForeColor = [Drawing.Color]::White
        $l = New-Object Windows.Forms.Label
        $l.Text = $text; $l.Dock = "Fill"; $l.TextAlign = "MiddleCenter"; $l.Font = New-Object Drawing.Font("Segoe UI", 11)
        $f.Controls.Add($l); $f.Show(); [Windows.Forms.Application]::DoEvents()
        return $f
    } catch { return $null }
}

#==============================================================================
# Execucao
$mutex = New-Object Threading.Mutex($false, "Local\ORBIT-Updater")
$haveLock = $false
try { $haveLock = $mutex.WaitOne(0) } catch { $haveLock = $true }
if (-not $haveLock) {
    if ($Launch -and (Test-Path $P.Exe)) { Start-Process $P.Exe }
    exit 0
}

$updated = @()
$exitCode = 0
try {
    $installed = Get-Installed
    $src = $null
    try {
        $src = Get-Manifest $(if ($Launch) { 5 } else { 30 })
    } catch {
        Write-Log "Sem conexao com o servidor de atualizacoes: $($_.Exception.Message)"
        if ($InstallFrom) { throw }
    }

    if ($src) {
        # 1) sistema primeiro (no modo Launch o app ainda esta fechado)
        $busy = $null
        if ($Launch -and $src.Manifest.packages.system -and (Test-Newer $src.Manifest.packages.system.version $installed.system) -and -not (Test-OrbitRunning)) {
            $busy = Show-Busy "Atualizando o ORBIT para $($src.Manifest.packages.system.version)..."
        }
        try {
            if (Update-Package $src "system" $installed) { $updated += "Sistema $($installed.system)" }
        } catch { Write-Log "Sistema: falhou ($($_.Exception.Message))"; $exitCode = 1 }
        if ($busy) { $busy.Close() }
    }

    # 2) abre o app sem esperar timbres e imagens
    if ($Launch -and (Test-Path $P.Exe) -and -not (Test-OrbitRunning)) { Start-Process $P.Exe }

    # 3) timbres e imagens (podem atualizar com o app aberto)
    if ($src) {
        foreach ($k in @("tones", "images")) {
            try { if (Update-Package $src $k $installed) { $updated += "$($names[$k]) $($installed[$k])" } }
            catch { Write-Log "$($names[$k]): falhou ($($_.Exception.Message))"; $exitCode = 1 }
        }
    }

    if ($Interactive) {
        Add-Type -AssemblyName System.Windows.Forms
        $msg = if (-not $src) { "Nao foi possivel falar com o servidor de atualizacoes.`nConfira a internet e tente de novo." }
               elseif ($updated.Count) { "Atualizado:`n  " + ($updated -join "`n  ") }
               else { "Tudo em dia.`n`nSistema $($installed.system)`nTimbres $($installed.tones)`nImagens $($installed.images)" }
        $pending = $script:report | Where-Object { $_ -match "adiado|falhou|quando o ORBIT" }
        if ($pending) { $msg += "`n`n" + ($pending -join "`n") }
        [void][Windows.Forms.MessageBox]::Show($msg, "ORBIT - Atualizacoes", "OK", "Information")
    } elseif ($updated.Count -and -not $InstallFrom) {
        Show-Balloon ("Atualizado: " + ($updated -join ", "))
    }
} catch {
    Write-Log "Erro: $($_.Exception.Message)"
    $exitCode = 2
    if ($Interactive) {
        Add-Type -AssemblyName System.Windows.Forms
        [void][Windows.Forms.MessageBox]::Show("Erro ao atualizar: $($_.Exception.Message)", "ORBIT - Atualizacoes", "OK", "Error")
    }
} finally {
    if (Test-Path $P.Temp) { Remove-Item -Recurse -Force $P.Temp -ErrorAction SilentlyContinue }
    if ($haveLock) { try { $mutex.ReleaseMutex() } catch {} }
}
exit $exitCode
