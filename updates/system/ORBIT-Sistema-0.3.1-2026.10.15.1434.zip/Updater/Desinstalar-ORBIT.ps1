﻿<#
  Remove o ORBIT deste usuario: app, plugin VST3, atalhos, atualizacao ao entrar no Windows e registro.
  Os seus presets (Documentos\ORBIT\Presets) nunca sao apagados. Timbres oficiais e imagens: pergunta antes.
    -Quiet      sem perguntas (mantem timbres e imagens)
    -TestRoot   pasta usada nos testes no lugar de LOCALAPPDATA, Documentos e atalhos
#>
param([switch] $Quiet, [string] $TestRoot = "")

$ErrorActionPreference = "Continue"
Add-Type -AssemblyName System.Windows.Forms
if ($TestRoot) {
    $local = Join-Path $TestRoot "LocalAppData"; $docs = Join-Path $TestRoot "Documents"
    $desktop = Join-Path $TestRoot "Desktop"; $startMenu = Join-Path $TestRoot "StartMenu"; $startup = Join-Path $TestRoot "Startup"
} else {
    $local = $env:LOCALAPPDATA; $docs = [Environment]::GetFolderPath("MyDocuments")
    $desktop = [Environment]::GetFolderPath("Desktop"); $startMenu = [Environment]::GetFolderPath("Programs"); $startup = [Environment]::GetFolderPath("Startup")
}
$app = Join-Path $local "Programs\ORBIT"
$vst3 = Join-Path $local "Programs\Common\VST3\ORBIT.vst3"

if (-not $Quiet) {
    $r = [Windows.Forms.MessageBox]::Show("Remover o ORBIT deste computador?`n`nSeus presets em Documentos\ORBIT\Presets ficam guardados.", "Desinstalar ORBIT", "YesNo", "Question")
    if ($r -ne "Yes") { exit 0 }
}
if (Get-Process -Name "ORBIT" -ErrorAction SilentlyContinue | Where-Object { $_.Path -like "$app*" }) {
    if ($Quiet) { Write-Host "Feche o ORBIT antes de desinstalar."; exit 1 }
    [void][Windows.Forms.MessageBox]::Show("Feche o ORBIT e rode o desinstalador de novo.", "Desinstalar ORBIT", "OK", "Warning")
    exit 1
}

$extras = $false
if (-not $Quiet) {
    $extras = [Windows.Forms.MessageBox]::Show("Apagar tambem os timbres oficiais (Presets\ORBIT Timbres) e as imagens dos equipamentos (Documentos\ORBIT\Images)?",
                                               "Desinstalar ORBIT", "YesNo", "Question") -eq "Yes"
}

Set-Location $env:TEMP          # este script roda de dentro da pasta que vai ser apagada
foreach ($p in @((Join-Path $desktop "ORBIT.lnk"), (Join-Path $startMenu "ORBIT"), (Join-Path $startup "ORBIT - atualizacoes.lnk"), $vst3, $app)) {
    if (Test-Path $p) { Remove-Item -Recurse -Force $p }
}
if ($extras) {
    foreach ($p in @((Join-Path $docs "ORBIT\Presets\ORBIT Timbres"), (Join-Path $docs "ORBIT\Images"))) { if (Test-Path $p) { Remove-Item -Recurse -Force $p } }
}
if (-not $TestRoot) { Remove-Item -Recurse -Force "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\ORBIT" -ErrorAction SilentlyContinue }

if (-not $Quiet) { [void][Windows.Forms.MessageBox]::Show("ORBIT removido.", "Desinstalar ORBIT", "OK", "Information") }
exit 0
