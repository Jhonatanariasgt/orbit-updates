' ORBIT: abre o atualizador sem janela de console.
'   ORBIT-Launcher.vbs           -> confere atualizacoes do sistema e abre o ORBIT
'   ORBIT-Launcher.vbs silent    -> so atualiza (usado ao entrar no Windows)
'   ORBIT-Launcher.vbs check     -> "Verificar atualizacoes" (mostra o resultado)
Set sh = CreateObject("WScript.Shell")
dir = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)
mode = "-Launch"
If WScript.Arguments.Count > 0 Then
    If LCase(WScript.Arguments(0)) = "silent" Then mode = "-Silent"
    If LCase(WScript.Arguments(0)) = "check" Then mode = "-Interactive"
End If
sh.Run "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & dir & "\ORBIT-Updater.ps1"" " & mode, 0, False
